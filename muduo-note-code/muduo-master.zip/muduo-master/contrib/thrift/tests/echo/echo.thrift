namespace cpp echo
namespace py echo

service Echo
{
  string echo(1: string arg);
}

